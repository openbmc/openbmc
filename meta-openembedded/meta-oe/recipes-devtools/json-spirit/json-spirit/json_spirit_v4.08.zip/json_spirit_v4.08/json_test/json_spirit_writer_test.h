#ifndef JSON_SPIRIT_WRITER_TEST
#define JSON_SPIRIT_WRITER_TEST

//          Copyright John W. Wilkinson 2007 - 2014
// Distributed under the MIT License, see accompanying file LICENSE.txt

// json spirit version 4.08

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

namespace json_spirit
{
    void test_writer();
}

#endif
